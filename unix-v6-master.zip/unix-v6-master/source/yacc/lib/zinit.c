yyinit(){}
