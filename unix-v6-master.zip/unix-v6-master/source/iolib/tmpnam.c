int IEH0958g 0;
tmpnam(s)
	char *s;
{
printf(-1,s,"pl%d%c",getpid(),'a'+IEH0958g++);
return(s);
}
