getchar()
{
extern cin;
return (cgetc(cin));
}
