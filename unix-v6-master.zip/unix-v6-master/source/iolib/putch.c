putchar (c)
char c;
{
extern cout;
cputc(c,cout);
}
