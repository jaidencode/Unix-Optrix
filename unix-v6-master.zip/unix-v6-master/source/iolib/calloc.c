calloc(n, s)
{
return(alloc(n*s));
}
