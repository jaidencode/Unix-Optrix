cfree (ptr)
{
free(ptr);
}
