# UNIX 6th Edition Kernel Source Code

from [www.tom-yam.or.jp/2238/src](http://www.tom-yam.or.jp/2238/src).

# Documents
- [Commentary on the Sixth Edition UNIX Operating System](http://www.lemis.com/grog/Documentation/Lions/)
- [The Unix Tree (Minnie's Home Page)](http://minnie.tuhs.org/cgi-bin/utree.pl)

