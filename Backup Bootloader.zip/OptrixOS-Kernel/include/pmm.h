#ifndef PMM_H
#define PMM_H
void pmm_init(void);
void* pmm_alloc(void);
void pmm_free(void*);
#endif
