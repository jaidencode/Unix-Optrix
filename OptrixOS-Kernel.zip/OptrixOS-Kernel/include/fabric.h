#ifndef FABRIC_H
#define FABRIC_H

#ifdef __cplusplus
extern "C" {
#endif

void fabric_main(void);

#ifdef __cplusplus
}
#endif

#endif // FABRIC_H
