#ifndef FABRIC_DEFS_H
#define FABRIC_DEFS_H

#define WIDTH  1024
#define HEIGHT 768

#endif
